package com.anz.wholesale;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WholesaleApplication {

	public static void main(String[] args) {
		SpringApplication.run(WholesaleApplication.class, args);
	}

}
