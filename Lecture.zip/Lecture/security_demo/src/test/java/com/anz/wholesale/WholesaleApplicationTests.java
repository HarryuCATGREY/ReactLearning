package com.anz.wholesale;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WholesaleApplicationTests {

	@Test
	void contextLoads() {
	}

}
