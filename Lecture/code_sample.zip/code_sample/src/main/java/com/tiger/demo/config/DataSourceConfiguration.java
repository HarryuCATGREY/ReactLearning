package com.tiger.demo.config;

public class DataSourceConfiguration {
}
