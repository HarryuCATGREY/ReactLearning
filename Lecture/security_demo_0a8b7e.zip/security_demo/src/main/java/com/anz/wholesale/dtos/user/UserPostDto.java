package com.anz.wholesale.dtos.user;

public class UserPostDto {
}
